/**
 * @var movies : array containing the movies from the dataset
 * @var <genre>_movies : array containing the <genre> movies
 * @var other_movies : array containing all the movies with all other genres
 */
var movies = [];
var action_movies = [];
var   action_totalprofit = 0,
      action_domesticprofit = 0,
      action_worldwideprofit = 0,
      action_budget = 0,
      action_votes = 0,
      action_rating = 0;
var adventure_movies = [];
var   adventure_totalprofit = 0,
      adventure_domesticprofit = 0,
      adventure_worldwideprofit = 0,
      adventure_budget = 0,
      adventure_votes = 0,
      adventure_rating = 0;
var comedy_movies = [];
var   comedy_totalprofit = 0,
      comedy_domesticprofit = 0,
      comedy_worldwideprofit = 0,
      comedy_budget = 0,
      comedy_votes = 0,
      comedy_rating = 0;
var crime_movies = [];
var   crime_totalprofit = 0,
      crime_domesticprofit = 0,
      crime_worldwideprofit = 0,
      crime_budget = 0,
      crime_votes = 0,
      crime_rating = 0;
var drama_movies = [];
var   drama_totalprofit = 0,
      drama_domesticprofit = 0,
      drama_worldwideprofit = 0,
      drama_budget = 0,
      drama_votes = 0,
      drama_rating = 0;
var fantasy_movies = [];
var   fantasy_totalprofit = 0,
      fantasy_domesticprofit = 0,
      fantasy_worldwideprofit = 0,
      fantasy_budget = 0,
      fantasy_votes = 0,
      fantasy_rating = 0;
var horror_movies = [];
var   horror_totalprofit = 0,
      horror_domesticprofit = 0,
      horror_worldwideprofit = 0,
      horror_budget = 0,
      horror_votes = 0,
      horror_rating = 0;
var mystery_movies = [];
var   mystery_totalprofit = 0,
      mystery_domesticprofit = 0,
      mystery_worldwideprofit = 0,
      mystery_budget = 0,
      mystery_votes = 0,
      mystery_rating = 0;
var romance_movies = [];
var   romance_totalprofit = 0,
      romance_domesticprofit = 0,
      romance_worldwideprofit = 0,
      romance_budget = 0,
      romance_votes = 0,
      romance_rating = 0;
var scifi_movies = [];
var   scifi_totalprofit = 0,
      scifi_domesticprofit = 0,
      scifi_worldwideprofit = 0,
      scifi_budget = 0,
      scifi_votes = 0,
      scifi_rating = 0;
var thriller_movies = [];
var   thriller_totalprofit = 0,
      thriller_domesticprofit = 0,
      thriller_worldwideprofit = 0,
      thriller_budget = 0,
      thriller_votes = 0,
      thriller_rating = 0;
var other_movies = [];
var   other_totalprofit = 0,
      other_domesticprofit = 0,
      other_worldwideprofit = 0,
      other_budget = 0,
      other_votes = 0,
      other_rating = 0;
//////////////////////////////////////  
//////// FILTER DATA /////////////////
//////////////////////////////////////  
function filter_movies(dataset) {
  reset_variables();/*
  dataset.forEach(function(d){
        movies.push(d);
  });*/
  movies = dataset;
  // filter by genre
  movies.forEach(function(d){
      if(checkMovieGender(d,"Action")) {
            action_movies.push(d);
            action_votes += (+d["votes"]);
            action_rating += (+d["rating"]);
            action_budget += (+d["ProductionBudget"]);
            action_domesticprofit += (+d["domesticProfit"]);
            action_worldwideprofit += (+d["worldwideProfit"]);
            action_totalprofit += (+d["totalProfit"]);
      }
      if( checkMovieGender(d,"Adventure")) {
            adventure_movies.push(d);
            adventure_votes += (+d["votes"]);
            adventure_rating += (+d["rating"]);
            adventure_budget += (+d["ProductionBudget"]);
            adventure_domesticprofit += (+d["domesticProfit"]);
            adventure_worldwideprofit += (+d["worldwideProfit"]);
            adventure_totalprofit += (+d["totalProfit"]);
      }
      if( checkMovieGender(d,"Comedy")) {
            comedy_movies.push(d);
            comedy_votes += (+d["votes"]);
            comedy_rating += (+d["rating"]);
            comedy_budget += (+d["ProductionBudget"]);
            comedy_domesticprofit += (+d["domesticProfit"]);
            comedy_worldwideprofit += (+d["worldwideProfit"]);
            comedy_totalprofit += (+d["totalProfit"]);
      }
      if(  checkMovieGender(d,"Crime")) {
            crime_movies.push(d);
            crime_votes += (+d["votes"]);
            crime_rating += (+d["rating"]);
            crime_budget += (+d["ProductionBudget"]);
            crime_domesticprofit += (+d["domesticProfit"]);
            crime_worldwideprofit += (+d["worldwideProfit"]);
            crime_totalprofit += (+d["totalProfit"]);
      }
      if( checkMovieGender(d,"Drama")) {
            drama_movies.push(d);
            drama_votes += (+d["votes"]);
            drama_rating += (+d["rating"]);
            drama_budget += (+d["ProductionBudget"]);
            drama_domesticprofit += (+d["domesticProfit"]);
            drama_worldwideprofit += (+d["worldwideProfit"]);
            drama_totalprofit += (+d["totalProfit"]);
      }
      if(  checkMovieGender(d,"Fantasy")) {
            fantasy_movies.push(d);
            fantasy_votes += (+d["votes"]);
            fantasy_rating += (+d["rating"]);
            fantasy_budget += (+d["ProductionBudget"]);
            fantasy_domesticprofit += (+d["domesticProfit"]);
            fantasy_worldwideprofit += (+d["worldwideProfit"]);
            fantasy_totalprofit += (+d["totalProfit"]);
      }
      if( checkMovieGender(d,"Horror")) {
            horror_movies.push(d);
            horror_votes += (+d["votes"]);
            horror_rating += (+d["rating"]);
            horror_budget += (+d["ProductionBudget"]);
            horror_domesticprofit += (+d["domesticProfit"]);
            horror_worldwideprofit += (+d["worldwideProfit"]);
            horror_totalprofit += (+d["totalProfit"]);
      }
      if( checkMovieGender(d,"Mystery")) {
            mystery_movies.push(d);
            mystery_votes += (+d["votes"]);
            mystery_rating += (+d["rating"]);
            mystery_budget += (+d["ProductionBudget"]);
            mystery_domesticprofit += (+d["domesticProfit"]);
            mystery_worldwideprofit += (+d["worldwideProfit"]);
            mystery_totalprofit += (+d["totalProfit"]);
      }
      if( checkMovieGender(d,"Romance")) {
            romance_movies.push(d);
            romance_votes += (+d["votes"]);
            romance_rating += (+d["rating"]);
            romance_budget += (+d["ProductionBudget"]);
            romance_domesticprofit += (+d["domesticProfit"]);
            romance_worldwideprofit += (+d["worldwideProfit"]);
            romance_totalprofit += (+d["totalProfit"]);
      }
      if( checkMovieGender(d,"Sci-Fi")) {
            scifi_movies.push(d);
            scifi_votes += (+d["votes"]);
            scifi_rating += (+d["rating"]);
            scifi_budget += (+d["ProductionBudget"]);
            scifi_domesticprofit += (+d["domesticProfit"]);
            scifi_worldwideprofit += (+d["worldwideProfit"]);
            scifi_totalprofit += (+d["totalProfit"]);
      }
      if(  checkMovieGender(d,"Thriller")) {
            thriller_movies.push(d);
            thriller_votes += (+d["votes"]);
            thriller_rating += (+d["rating"]);
            thriller_budget += (+d["ProductionBudget"]);
            thriller_domesticprofit += (+d["domesticProfit"]);
            thriller_worldwideprofit += (+d["worldwideProfit"]);
            thriller_totalprofit += (+d["totalProfit"]);
      }
      if( checkMovieGender(d,"Other")) {
            other_movies.push(d);
            other_votes += (+d["votes"]);
            other_rating += (+d["rating"]);
            other_budget += (+d["ProductionBudget"]);
            other_domesticprofit += (+d["domesticProfit"]);
            other_worldwideprofit += (+d["worldwideProfit"]);
            other_totalprofit += (+d["totalProfit"]);
      }
  });
      // Max values for each axis
      max_votes = 300000000;
      max_budget = 150000000;
      max_rating = 10;
      max_domesticprofit = 100000000;
      max_worldwideprofit = 200000000;
      max_totalprofit = 200000000;

      //calculating Max values for each axis
      /*
      var max_votes = Math.max(
            (action_votes/action_movies.length),
            (adventure_votes/adventure_movies.length),
            (comedy_votes/comedy_movies.length),
            (crime_votes/crime_movies.length),
            (drama_votes/drama_movies.length),
            (fantasy_votes/fantasy_movies.length),
            (horror_votes/horror_movies.length),
            (mystery_votes/mystery_movies.length),
            (romance_votes/romance_movies.length),
            (scifi_votes/scifi_movies.length),
            (thriller_votes/thriller_movies.length),
            (other_votes/other_movies.length));
      var max_rating = 10;
      var max_budget = Math.max(
            (action_budget/action_movies.length),
            (adventure_budget/adventure_movies.length),
            (comedy_budget/comedy_movies.length),
            (crime_budget/crime_movies.length),
            (drama_budget/drama_movies.length),
            (fantasy_budget/fantasy_movies.length),
            (horror_budget/horror_movies.length),
            (mystery_budget/mystery_movies.length),
            (romance_budget/romance_movies.length),
            (scifi_budget/scifi_movies.length),
            (thriller_budget/thriller_movies.length),
            (other_budget/other_movies.length));
      var max_domesticprofit = Math.max(
            (action_domesticprofit/action_movies.length),
            (adventure_domesticprofit/adventure_movies.length),
            (comedy_domesticprofit/comedy_movies.length),
            (crime_domesticprofit/crime_movies.length),
            (drama_domesticprofit/drama_movies.length),
            (fantasy_domesticprofit/fantasy_movies.length),
            (horror_domesticprofit/horror_movies.length),
            (mystery_domesticprofit/mystery_movies.length),
            (romance_domesticprofit/romance_movies.length),
            (scifi_domesticprofit/scifi_movies.length),
            (thriller_domesticprofit/thriller_movies.length),
            (other_domesticprofit/other_movies.length));
      var max_worldwideprofit = Math.max(
            (action_worldwideprofit/action_movies.length),
            (adventure_worldwideprofit/adventure_movies.length),
            (comedy_worldwideprofit/comedy_movies.length),
            (crime_worldwideprofit/crime_movies.length),
            (drama_worldwideprofit/drama_movies.length),
            (fantasy_worldwideprofit/fantasy_movies.length),
            (horror_worldwideprofit/horror_movies.length),
            (mystery_worldwideprofit/mystery_movies.length),
            (romance_worldwideprofit/romance_movies.length),
            (scifi_worldwideprofit/scifi_movies.length),
            (thriller_worldwideprofit/thriller_movies.length),
            (other_worldwideprofit/other_movies.length));
      var max_totalprofit = Math.max(
            (action_totalprofit/action_movies.length),
            (adventure_totalprofit/adventure_movies.length),
            (comedy_totalprofit/comedy_movies.length),
            (crime_totalprofit/crime_movies.length),
            (drama_totalprofit/drama_movies.length),
            (fantasy_totalprofit/fantasy_movies.length),
            (horror_totalprofit/horror_movies.length),
            (mystery_totalprofit/mystery_movies.length),
            (romance_totalprofit/romance_movies.length),
            (scifi_totalprofit/scifi_movies.length),
            (thriller_totalprofit/thriller_movies.length),
            (other_totalprofit/other_movies.length));
      */
      
      ////////////// ACTION /////////////////
      if(action_movies.length != 0 ) {
            action_data[0].axes[0].value = Math.ceil(((action_votes/action_movies.length)*100)/max_votes);
            action_data[0].axes[1].value = Math.ceil((action_rating/action_movies.length)*10);
            action_data[0].axes[2].value = Math.ceil(((action_budget/action_movies.length)*100)/max_budget);
            action_data[0].axes[3].value = Math.ceil(((action_domesticprofit/action_movies.length)*100)/max_domesticprofit);
            action_data[0].axes[4].value = Math.ceil(((action_worldwideprofit/action_movies.length)*100)/max_worldwideprofit);
            action_data[0].axes[5].value = Math.ceil(((action_totalprofit/action_movies.length)*100)/max_totalprofit);
            fixValues(action_data);
      } else {
            // default values, in case there are no selected movies of this genre
            defaultValues(action_data);
      }
      ////////////// ADVENTURE /////////////////
      if(adventure_movies.length != 0 ) {
            adventure_data[0].axes[0].value = Math.ceil(((adventure_votes/adventure_movies.length)*100)/max_votes);
            adventure_data[0].axes[1].value = Math.ceil((adventure_rating/adventure_movies.length)*10);
            adventure_data[0].axes[2].value = Math.ceil(((adventure_budget/adventure_movies.length)*100)/max_budget);
            adventure_data[0].axes[3].value = Math.ceil(((adventure_domesticprofit/adventure_movies.length)*100)/max_domesticprofit);
            adventure_data[0].axes[4].value = Math.ceil(((adventure_worldwideprofit/adventure_movies.length)*100)/max_worldwideprofit);
            adventure_data[0].axes[5].value = Math.ceil(((adventure_totalprofit/adventure_movies.length)*100)/max_totalprofit);
            fixValues(adventure_data);
      } else {
            // default values, in case there are no selected movies of this genre
            defaultValues(adventure_data);
      }
      ////////////// COMEDY /////////////////
      if(comedy_movies.length != 0 ) {
            comedy_data[0].axes[0].value = Math.ceil(((comedy_votes/comedy_movies.length)*100)/max_votes);
            comedy_data[0].axes[1].value = Math.ceil((comedy_rating/comedy_movies.length)*10);
            comedy_data[0].axes[2].value = Math.ceil(((comedy_budget/comedy_movies.length)*100)/max_budget);
            comedy_data[0].axes[3].value = Math.ceil(((comedy_domesticprofit/comedy_movies.length)*100)/max_domesticprofit);
            comedy_data[0].axes[4].value = Math.ceil(((comedy_worldwideprofit/comedy_movies.length)*100)/max_worldwideprofit);
            comedy_data[0].axes[5].value = Math.ceil(((comedy_totalprofit/comedy_movies.length)*100)/max_totalprofit);
            fixValues(comedy_data);
      } else {
            // default values, in case there are no selected movies of this genre
            defaultValues(comedy_data);
      }
      ////////////// CRIME /////////////////
      if(crime_movies.length != 0 ) {
            crime_data[0].axes[0].value = Math.ceil(((crime_votes/crime_movies.length)*100)/max_votes);
            crime_data[0].axes[1].value = Math.ceil((crime_rating/crime_movies.length)*10);
            crime_data[0].axes[2].value = Math.ceil(((crime_budget/crime_movies.length)*100)/max_budget);
            crime_data[0].axes[3].value = Math.ceil(((crime_domesticprofit/crime_movies.length)*100)/max_domesticprofit);
            crime_data[0].axes[4].value = Math.ceil(((crime_worldwideprofit/crime_movies.length)*100)/max_worldwideprofit);
            crime_data[0].axes[5].value = Math.ceil(((crime_totalprofit/crime_movies.length)*100)/max_totalprofit);
            fixValues(crime_data);
      } else {
            // default values, in case there are no selected movies of this genre
            defaultValues(crime_data);
      }
      ////////////// DRAMA /////////////////
      if(drama_movies.length != 0 ) {
            drama_data[0].axes[0].value = Math.ceil(((drama_votes/drama_movies.length)*100)/max_votes);
            drama_data[0].axes[1].value = Math.ceil((drama_rating/drama_movies.length)*10);
            drama_data[0].axes[2].value = Math.ceil(((drama_budget/drama_movies.length)*100)/max_budget);
            drama_data[0].axes[3].value = Math.ceil(((drama_domesticprofit/drama_movies.length)*100)/max_domesticprofit);
            drama_data[0].axes[4].value = Math.ceil(((drama_worldwideprofit/drama_movies.length)*100)/max_worldwideprofit);
            drama_data[0].axes[5].value = Math.ceil(((drama_totalprofit/drama_movies.length)*100)/max_totalprofit);
            fixValues(drama_data);
      } else {
            // default values, in case there are no selected movies of this genre
            defaultValues(drama_data);
      }
      ////////////// FANTASY /////////////////
      if(fantasy_movies.length != 0 ) {
            fantasy_data[0].axes[0].value = Math.ceil(((fantasy_votes/fantasy_movies.length)*100)/max_votes);
            fantasy_data[0].axes[1].value = Math.ceil((fantasy_rating/fantasy_movies.length)*10);
            fantasy_data[0].axes[2].value = Math.ceil(((fantasy_budget/fantasy_movies.length)*100)/max_budget);
            fantasy_data[0].axes[3].value = Math.ceil(((fantasy_domesticprofit/fantasy_movies.length)*100)/max_domesticprofit);
            fantasy_data[0].axes[4].value = Math.ceil(((fantasy_worldwideprofit/fantasy_movies.length)*100)/max_worldwideprofit);
            fantasy_data[0].axes[5].value = Math.ceil(((fantasy_totalprofit/fantasy_movies.length)*100)/max_totalprofit);
            fixValues(fantasy_data);
      } else {
            // default values, in case there are no selected movies of this genre
            defaultValues(fantasy_data);
      }
      ////////////// HORROR /////////////////
      if(horror_movies.length != 0 ) {
            horror_data[0].axes[0].value = Math.ceil(((horror_votes/horror_movies.length)*100)/max_votes);
            horror_data[0].axes[1].value = Math.ceil((horror_rating/horror_movies.length)*10);
            horror_data[0].axes[2].value = Math.ceil(((horror_budget/horror_movies.length)*100)/max_budget);
            horror_data[0].axes[3].value = Math.ceil(((horror_domesticprofit/horror_movies.length)*100)/max_domesticprofit);
            horror_data[0].axes[4].value = Math.ceil(((horror_worldwideprofit/horror_movies.length)*100)/max_worldwideprofit);
            horror_data[0].axes[5].value = Math.ceil(((horror_totalprofit/horror_movies.length)*100)/max_totalprofit);
            fixValues(horror_data);
      } else {
            // default values, in case there are no selected movies of this genre
            defaultValues(horror_data);
      }
      ////////////// MYSTERY /////////////////
      if(mystery_movies.length != 0 ) {
            mystery_data[0].axes[0].value = Math.ceil(((mystery_votes/mystery_movies.length)*100)/max_votes);
            mystery_data[0].axes[1].value = Math.ceil((mystery_rating/mystery_movies.length)*10);
            mystery_data[0].axes[2].value = Math.ceil(((mystery_budget/mystery_movies.length)*100)/max_budget);
            mystery_data[0].axes[3].value = Math.ceil(((mystery_domesticprofit/mystery_movies.length)*100)/max_domesticprofit);
            mystery_data[0].axes[4].value = Math.ceil(((mystery_worldwideprofit/mystery_movies.length)*100)/max_worldwideprofit);
            mystery_data[0].axes[5].value = Math.ceil(((mystery_totalprofit/mystery_movies.length)*100)/max_totalprofit);
            fixValues(mystery_data);
      } else {
            // default values, in case there are no selected movies of this genre
            defaultValues(mystery_data);
      }
      ////////////// ROMANCE /////////////////
      if(romance_movies.length != 0 ) {
            romance_data[0].axes[0].value = Math.ceil(((romance_votes/romance_movies.length)*100)/max_votes);
            romance_data[0].axes[1].value = Math.ceil((romance_rating/romance_movies.length)*10);
            romance_data[0].axes[2].value = Math.ceil(((romance_budget/romance_movies.length)*100)/max_budget);
            romance_data[0].axes[3].value = Math.ceil(((romance_domesticprofit/romance_movies.length)*100)/max_domesticprofit);
            romance_data[0].axes[4].value = Math.ceil(((romance_worldwideprofit/romance_movies.length)*100)/max_worldwideprofit);
            romance_data[0].axes[5].value = Math.ceil(((romance_totalprofit/romance_movies.length)*100)/max_totalprofit);
            fixValues(romance_data);
      } else {
            // default values, in case there are no selected movies of this genre
            defaultValues(romance_data);
      }
      ////////////// SCI-FI /////////////////
      if(scifi_movies.length != 0 ) {
            scifi_data[0].axes[0].value = Math.ceil(((scifi_votes/scifi_movies.length)*100)/max_votes);
            scifi_data[0].axes[1].value = Math.ceil((scifi_rating/scifi_movies.length)*10);
            scifi_data[0].axes[2].value = Math.ceil(((scifi_budget/scifi_movies.length)*100)/max_budget);
            scifi_data[0].axes[3].value = Math.ceil(((scifi_domesticprofit/scifi_movies.length)*100)/max_domesticprofit);
            scifi_data[0].axes[4].value = Math.ceil(((scifi_worldwideprofit/scifi_movies.length)*100)/max_worldwideprofit);
            scifi_data[0].axes[5].value = Math.ceil(((scifi_totalprofit/scifi_movies.length)*100)/max_totalprofit);
            fixValues(scifi_data);
      } else {
            // default values, in case there are no selected movies of this genre
            defaultValues(scifi_data);
      }
      ////////////// THRILLER /////////////////
      if(thriller_movies.length != 0 ) {
            thriller_data[0].axes[0].value = Math.ceil(((thriller_votes/thriller_movies.length)*100)/max_votes);
            thriller_data[0].axes[1].value = Math.ceil((thriller_rating/thriller_movies.length)*10);
            thriller_data[0].axes[2].value = Math.ceil(((thriller_budget/thriller_movies.length)*100)/max_budget);
            thriller_data[0].axes[3].value = Math.ceil(((thriller_domesticprofit/thriller_movies.length)*100)/max_domesticprofit);
            thriller_data[0].axes[4].value = Math.ceil(((thriller_worldwideprofit/thriller_movies.length)*100)/max_worldwideprofit);
            thriller_data[0].axes[5].value = Math.ceil(((thriller_totalprofit/thriller_movies.length)*100)/max_totalprofit);
            fixValues(thriller_data);
      } else {
            // default values, in case there are no selected movies of this genre
            defaultValues(thriller_data);
      }
      ////////////// OTHER /////////////////
      if(other_movies.length != 0 ) {
            other_data[0].axes[0].value = Math.ceil(((other_votes/other_movies.length)*100)/max_votes);
            other_data[0].axes[1].value = Math.ceil((other_rating/other_movies.length)*10);
            other_data[0].axes[2].value = Math.ceil(((other_budget/other_movies.length)*100)/max_budget);
            other_data[0].axes[3].value = Math.ceil(((other_domesticprofit/other_movies.length)*100)/max_domesticprofit);
            other_data[0].axes[4].value = Math.ceil(((other_worldwideprofit/other_movies.length)*100)/max_worldwideprofit);
            other_data[0].axes[5].value = Math.ceil(((other_totalprofit/other_movies.length)*100)/max_totalprofit);
            fixValues(other_data);
      } else {
            // default values, in case there are no selected movies of this genre
            defaultValues(other_data);
      }
}

/**
 * @function reset_variables
 * description: resets all the variables
 */
function reset_variables() {
      action_movies = [];
      action_totalprofit = 0,
      action_domesticprofit = 0,
      action_worldwideprofit = 0,
      action_budget = 0,
      action_votes = 0,
      action_rating = 0;
      adventure_movies = [];
      adventure_totalprofit = 0,
      adventure_domesticprofit = 0,
      adventure_worldwideprofit = 0,
      adventure_budget = 0,
      adventure_votes = 0,
      adventure_rating = 0;
      comedy_movies = [];
      comedy_totalprofit = 0,
      comedy_domesticprofit = 0,
      comedy_worldwideprofit = 0,
      comedy_budget = 0,
      comedy_votes = 0,
      comedy_rating = 0;
      crime_movies = [];
      crime_totalprofit = 0,
      crime_domesticprofit = 0,
      crime_worldwideprofit = 0,
      crime_budget = 0,
      crime_votes = 0,
      crime_rating = 0;
      drama_movies = [];
      drama_totalprofit = 0,
      drama_domesticprofit = 0,
      drama_worldwideprofit = 0,
      drama_budget = 0,
      drama_votes = 0,
      drama_rating = 0;
      fantasy_movies = [];
      fantasy_totalprofit = 0,
      fantasy_domesticprofit = 0,
      fantasy_worldwideprofit = 0,
      fantasy_budget = 0,
      fantasy_votes = 0,
      fantasy_rating = 0;
      horror_movies = [];
      horror_totalprofit = 0,
      horror_domesticprofit = 0,
      horror_worldwideprofit = 0,
      horror_budget = 0,
      horror_votes = 0,
      horror_rating = 0;
      mystery_movies = [];
      mystery_totalprofit = 0,
      mystery_domesticprofit = 0,
      mystery_worldwideprofit = 0,
      mystery_budget = 0,
      mystery_votes = 0,
      mystery_rating = 0;
      romance_movies = [];
      romance_totalprofit = 0,
      romance_domesticprofit = 0,
      romance_worldwideprofit = 0,
      romance_budget = 0,
      romance_votes = 0,
      romance_rating = 0;
      scifi_movies = [];
      scifi_totalprofit = 0,
      scifi_domesticprofit = 0,
      scifi_worldwideprofit = 0,
      scifi_budget = 0,
      scifi_votes = 0,
      scifi_rating = 0;
      thriller_movies = [];
      thriller_totalprofit = 0,
      thriller_domesticprofit = 0,
      thriller_worldwideprofit = 0,
      thriller_budget = 0,
      thriller_votes = 0,
      thriller_rating = 0;
      other_movies = [];
      other_totalprofit = 0,
      other_domesticprofit = 0,
      other_worldwideprofit = 0,
      other_budget = 0,
      other_votes = 0,
      other_rating = 0;
}

/**
 * @function checkMovieGender
 * @arg movie (object)
 * @arg gender (string)
 */
function checkMovieGender(movie, gender){
      if(gender == null) return true;
      if(gender != "Other"){
            if(   movie["genres/0"] == gender ||
                  movie["genres/1"] == gender ||
                  movie["genres/2"] == gender ||
                  movie["genres/3"] == gender ||
                  movie["genres/4"] == gender ||
                  movie["genres/5"] == gender ||
                  movie["genres/6"] == gender ||
                  movie["genres/7"] == gender )
                  return true;
            else return false;
      } else {
            if(   movie["genres/0"] == "Animation" ||
                  movie["genres/0"] == "Biography" ||
                  movie["genres/0"] == "Documentary" ||
                  movie["genres/0"] == "Family" ||
                  movie["genres/0"] == "History" ||
                  movie["genres/0"] == "Music" ||
                  movie["genres/0"] == "Musical" ||
                  movie["genres/0"] == "Short" ||
                  movie["genres/0"] == "Sport" ||
                  movie["genres/0"] == "War" ||
                  movie["genres/0"] == "Western" ||
                  movie["genres/1"] == "Animation" ||
                  movie["genres/1"] == "Biography" ||
                  movie["genres/1"] == "Documentary" ||
                  movie["genres/1"] == "Family" ||
                  movie["genres/1"] == "History" ||
                  movie["genres/1"] == "Music" ||
                  movie["genres/1"] == "Musical" ||
                  movie["genres/1"] == "Short" ||
                  movie["genres/1"] == "Sport" ||
                  movie["genres/1"] == "War" ||
                  movie["genres/1"] == "Western" ||
                  movie["genres/2"] == "Animation" ||
                  movie["genres/2"] == "Biography" ||
                  movie["genres/2"] == "Documentary" ||
                  movie["genres/2"] == "Family" ||
                  movie["genres/2"] == "History" ||
                  movie["genres/2"] == "Music" ||
                  movie["genres/2"] == "Musical" ||
                  movie["genres/2"] == "Short" ||
                  movie["genres/2"] == "Sport" ||
                  movie["genres/2"] == "War" ||
                  movie["genres/2"] == "Western" ||
                  movie["genres/3"] == "Animation" ||
                  movie["genres/3"] == "Biography" ||
                  movie["genres/3"] == "Documentary" ||
                  movie["genres/3"] == "Family" ||
                  movie["genres/3"] == "History" ||
                  movie["genres/3"] == "Music" ||
                  movie["genres/3"] == "Musical" ||
                  movie["genres/3"] == "Short" ||
                  movie["genres/3"] == "Sport" ||
                  movie["genres/3"] == "War" ||
                  movie["genres/3"] == "Western" ||
                  movie["genres/4"] == "Animation" ||
                  movie["genres/4"] == "Biography" ||
                  movie["genres/4"] == "Documentary" ||
                  movie["genres/4"] == "Family" ||
                  movie["genres/4"] == "History" ||
                  movie["genres/4"] == "Music" ||
                  movie["genres/4"] == "Musical" ||
                  movie["genres/4"] == "Short" ||
                  movie["genres/4"] == "Sport" ||
                  movie["genres/4"] == "War" ||
                  movie["genres/4"] == "Western" ||
                  movie["genres/5"] == "Animation" ||
                  movie["genres/5"] == "Biography" ||
                  movie["genres/5"] == "Documentary" ||
                  movie["genres/5"] == "Family" ||
                  movie["genres/5"] == "History" ||
                  movie["genres/5"] == "Music" ||
                  movie["genres/5"] == "Musical" ||
                  movie["genres/5"] == "Short" ||
                  movie["genres/5"] == "Sport" ||
                  movie["genres/5"] == "War" ||
                  movie["genres/5"] == "Western" ||
                  movie["genres/6"] == "Animation" ||
                  movie["genres/6"] == "Biography" ||
                  movie["genres/6"] == "Documentary" ||
                  movie["genres/6"] == "Family" ||
                  movie["genres/6"] == "History" ||
                  movie["genres/6"] == "Music" ||
                  movie["genres/6"] == "Musical" ||
                  movie["genres/6"] == "Short" ||
                  movie["genres/6"] == "Sport" ||
                  movie["genres/6"] == "War" ||
                  movie["genres/6"] == "Western" ||
                  movie["genres/7"] == "Animation" ||
                  movie["genres/7"] == "Biography" ||
                  movie["genres/7"] == "Documentary" ||
                  movie["genres/7"] == "Family" ||
                  movie["genres/7"] == "History" ||
                  movie["genres/7"] == "Music" ||
                  movie["genres/7"] == "Musical" ||
                  movie["genres/7"] == "Short" ||
                  movie["genres/7"] == "Sport" ||
                  movie["genres/7"] == "War" ||
                  movie["genres/7"] == "Western" )
                  return true;
            else return false;
      }
}

/**
 * @function fixValues
 * @arg radar_dataset
 * description : makes sure there are no values higher than 100 and lower than 15
 */
function fixValues(radar_dataset) {
      radar_dataset[0].axes.forEach(function(d){
            if(d.value > 99) d.value = 100;
            else if(d.value < 15) d.value = 15;
      });
}

/**
 * @function defaultValues
 * @arg radar_dataset
 * description: initializes all axis with some standart values
 */
function defaultValues(radar_dataset) {
      radar_dataset[0].axes[0].value = 15;
      radar_dataset[0].axes[1].value = 15;
      radar_dataset[0].axes[2].value = 15;
      radar_dataset[0].axes[3].value = 15;
      radar_dataset[0].axes[4].value = 15;
      radar_dataset[0].axes[5].value = 15;
}