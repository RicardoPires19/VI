/////////////////////////////////////
//////// Other variables ////////////
/////////////////////////////////////
var mouseovered_genre = null;
var selected_genre = null;
var control_flag = true;
var text, labels;
var chart = RadarChart.chart();
var chart2 = RadarChart.chart();
var cfg = chart.config(); // retrieve default config
var cfg2 = chart2.config();
var main_radar_height = cfg2.h / 1.5;
var main_radar_width = cfg2.w / 1.5;
var radar_svg = d3.select('#radar_svg')
              .attr('width', cfg.w * 1.5)
              .attr('height', cfg.h * 0.8);
             // var svg = d3.select('#parallel');
//////////////////////////////////////
/////// MY DATASET ///////////////////
//////////////////////////////////////
function draw_radar(dataset) {
    filter_movies(dataset);
    // generate the first radar
    gen_first_radar(selected_genre,mouseovered_genre);
    // many radars
    if(control_flag){
      chart.config({w: cfg.w / 6, h: cfg.h / 6, axisText: false, levels: 0, circles: false,maxValue: 100});
      cfg = chart.config();
      control_flag = false;
    }
    render();
}
//////////////////////////////////////  
///// FIRST RADAR ////////////////////
//////////////////////////////////////
function gen_first_radar(genre1,genre2) {
      var display_data = [];
      display_data = createDatasetToDisplay(genre1,genre2);;

      chart2.config({ w: main_radar_width, h: main_radar_height,radius:2,
                      axisText: true, maxValue: 100, levels:0 ,transitionDuration: 300});

      var single = radar_svg.selectAll('g.single').data([display_data]);
      single.enter().append('g').classed('single',1);
      single.attr('transform',function() { return 'translate(0,30)'; })
            .call(chart2)
            .on("click",function(d){
              if(d[0].className != "none"){
                selected_genre = d[0].className;
                brush();
              }
            });
            // on("keypressed")

      gen_title();

}
function gen_title() {
      // RADAR TITLE
      // delete the current title
      radar_svg.selectAll('text.display_title').remove();
      // create a new one
      text = radar_svg.selectAll('g.single')
                  .append("text");
            
      labels = text.attr("class","display_title")
                        .text(function(d){
                              if(d[0].className == "none") return d[0].title;
                              return d[0].className;
                        })
                        .attr('transform', function(d) {
                              if(d[0].className == "none") return 'translate('+ ((cfg2.w/2)-(3*d[0].title.length)) +',-15)';
                              return 'translate('+ ((cfg2.w/2)-(3*d[0].className.length)) +',-15)';
                        })
                        .attr("font-family", "sans-serif")
                        .attr("font-size","15px")
                        .attr("fill", "black");
}
//////////////////////////////////////  
///// MULTIPLE RADARS ////////////////
//////////////////////////////////////
function render() {
  //////////////////////////////////////
  ////// MULTIPLE RADARS ///////////////
  //////////////////////////////////////
  var game = radar_svg.selectAll('g.game').data(
    [
      action_data,
      adventure_data,
      comedy_data,
      crime_data,
      drama_data,
      fantasy_data,
      horror_data,
      mystery_data,
      romance_data,
      scifi_data,
      thriller_data,
      other_data
    ]
  );
  game.enter().append('g').classed('game', 1);
  game
    .attr('transform', function(d, i) {
      if ( i > 7) return 'translate('+((cfg.w * 5) + ((i % 4) * cfg.w))+','+ ((cfg.h * 1.3) + 150) +')';
      if ( i > 3) return 'translate('+((cfg.w * 5) + ((i % 4) * cfg.w))+','+ ((cfg.h * 1.3) + 50) +')';
      return 'translate('+((cfg.w * 5) + (i * cfg.w))+','+ ((cfg.h * 1.3) - 50) +')';
    })
    .call(chart);
  game.selectAll("polygon")
    .on("click", function(d) {
      if(selected_genre != null && selected_genre == d.className){
          selected_genre = null;
          brush();
      }
      else {
          selected_genre = d.className;
          brush();
      }
    })
    .on("mouseover",function(d){
      mouseovered_genre = d.className;
      if(mouseovered_genre != selected_genre) brush();
    })
    .on("mouseout",function(d){
      if(mouseovered_genre != selected_genre){
        mouseovered_genre = null;
        brush();
      } else mouseovered_genre = null;
    });

  gen_multiple_titles();
//    setTimeout(render, 1000);
}

function gen_multiple_titles (){
  // delete the current title
  //radar_svg.selectAll('text.multiples_title').text(null);
  radar_svg.selectAll('text.multiples_title').remove();
  
  var text2 = d3.selectAll('g.game')
                .append("text");
  var labels2 = text2.attr("class","multiples_title")
                      .attr('transform', function(d) {
                        if(d[0].className == "Adventure") return 'translate(-5,0)';
                        if(d[0].className == "Romance") return 'translate(-5,0)';
                        return 'translate('+ (d[0].className.length) +',0)';
                      })
                      .attr("font-family", "sans-serif")
                      .attr("font-size", function(d){
                        if( d[0].className == selected_genre ||
                            (mouseovered_movie_genres.indexOf(d[0].className) >= 0))
                            return "16px";
                        else return "11px";
                      })
                      .attr("fill", "black")
                      .text(function(d) {
                        return d[0].className;
                      });
}


/**
 * @function createDatasetToDisplay
 * @arg genre1
 * @arg genre2
 * Description: creates the dataset to be used
 * in the main radar with the genres given
 */
function createDatasetToDisplay(genre1, genre2) {
    if(genre1 != null && genre2 == null) return pushGenreDataToDataset(genre1);
    if(genre2 != null) return pushGenreDataToDataset(genre2);
    return no_data;
}

/**
 * @function pushGenreDataToDataset
 * @arg dataset
 * @arg genre
 */
function pushGenreDataToDataset(genre){
  var genre_dataset = [];
  if(genre == "Action") genre_dataset.push(action_data[0]);
  else if(genre == "Adventure") genre_dataset.push(adventure_data[0]);
  else if(genre == "Comedy") genre_dataset.push(comedy_data[0]);
  else if(genre == "Crime") genre_dataset.push(crime_data[0]);
  else if(genre == "Drama") genre_dataset.push(drama_data[0]);
  else if(genre == "Fantasy") genre_dataset.push(fantasy_data[0]);
  else if(genre == "Horror") genre_dataset.push(horror_data[0]);
  else if(genre == "Mystery") genre_dataset.push(mystery_data[0]);
  else if(genre == "Romance") genre_dataset.push(romance_data[0]);
  else if(genre == "Sci-Fi") genre_dataset.push(scifi_data[0]);
  else if(genre == "Thriller") genre_dataset.push(thriller_data[0]);
  else if(genre == "Other") genre_dataset.push(other_data[0]);
  else if(genre == "Animation") genre_dataset.push(other_data[0]);
  else if(genre == "Biography") genre_dataset.push(other_data[0]);
  else if(genre == "Documentary") genre_dataset.push(other_data[0]);
  else if(genre == "Family") genre_dataset.push(other_data[0]);
  else if(genre == "History") genre_dataset.push(other_data[0]);
  else if(genre == "Music") genre_dataset.push(other_data[0]);
  else if(genre == "Musical") genre_dataset.push(other_data[0]);
  else if(genre == "Short") genre_dataset.push(other_data[0]);
  else if(genre == "Sport") genre_dataset.push(other_data[0]);
  else if(genre == "War") genre_dataset.push(other_data[0]);
  else if(genre == "Western") genre_dataset.push(other_data[0]);
  else genre_dataset.push(no_data[0]);
  return genre_dataset;
}