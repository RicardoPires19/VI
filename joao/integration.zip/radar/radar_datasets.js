//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
/////// RADARS DATASETS //////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
var action_data = [
  {
    // COLOR :  To change the color , go to the ex07.css and change the color there
    className: 'Action', // optional can be used for styling
    axes: [
      // value range [0,100], any values outside this range will change the values in the other axis
      {axis: "votes", value: 1}, 
      {axis: "rating", value: 1}, 
      {axis: "budget", value: 1},  
      {axis: "domesticprofit", value: 1},  
      {axis: "worldwideprofit", value: 1},
      {axis: "totalprofit", value: 1}
    ]
  }
];
var adventure_data = [
  {
    // COLOR :  To change the color , go to the ex07.css and change the color there
    className: 'Adventure', // optional can be used for styling
    axes: [
      // value range [0,100], any values outside this range will change the values in the other axis
      {axis: "votes", value: 1}, 
      {axis: "rating", value: 1}, 
      {axis: "budget", value: 1},  
      {axis: "domesticprofit", value: 1},  
      {axis: "worldwideprofit", value: 1},
      {axis: "totalprofit", value: 1}
    ]
  }
];
var comedy_data = [
  {
    // COLOR :  To change the color , go to the ex07.css and change the color there
    className: 'Comedy', // optional can be used for styling
    axes: [
      // value range [0,100], any values outside this range will change the values in the other axis
      {axis: "votes", value: 1}, 
      {axis: "rating", value: 1}, 
      {axis: "budget", value: 1},  
      {axis: "domesticprofit", value: 1},  
      {axis: "worldwideprofit", value: 1},
      {axis: "totalprofit", value: 1}
    ]
  }
];
var crime_data = [
  {
    // COLOR :  To change the color , go to the ex07.css and change the color there
    className: 'Crime', // optional can be used for styling
    axes: [
      // value range [0,100], any values outside this range will change the values in the other axis
      {axis: "votes", value: 1}, 
      {axis: "rating", value: 1}, 
      {axis: "budget", value: 1},  
      {axis: "domesticprofit", value: 1},  
      {axis: "worldwideprofit", value: 1},
      {axis: "totalprofit", value: 1}
    ]
  }
];
var drama_data = [
  {
    // COLOR :  To change the color , go to the ex07.css and change the color there
    className: 'Drama', // optional can be used for styling
    axes: [
      // value range [0,100], any values outside this range will change the values in the other axis
      {axis: "votes", value: 1}, 
      {axis: "rating", value: 1}, 
      {axis: "budget", value: 1},  
      {axis: "domesticprofit", value: 1},  
      {axis: "worldwideprofit", value: 1},
      {axis: "totalprofit", value: 1}
    ]
  }
];
var fantasy_data = [
  {
    // COLOR :  To change the color , go to the ex07.css and change the color there
    className: 'Fantasy', // optional can be used for styling
    axes: [
      // value range [0,100], any values outside this range will change the values in the other axis
      {axis: "votes", value: 1}, 
      {axis: "rating", value: 1}, 
      {axis: "budget", value: 1},  
      {axis: "domesticprofit", value: 1},  
      {axis: "worldwideprofit", value: 1},
      {axis: "totalprofit", value: 1}
    ]
  }
];
var horror_data = [
  {
    // COLOR :  To change the color , go to the ex07.css and change the color there
    className: 'Horror', // optional can be used for styling
    axes: [
      // value range [0,100], any values outside this range will change the values in the other axis
      {axis: "votes", value: 1}, 
      {axis: "rating", value: 1}, 
      {axis: "budget", value: 1},  
      {axis: "domesticprofit", value: 1},  
      {axis: "worldwideprofit", value: 1},
      {axis: "totalprofit", value: 1}
    ]
  }
];
var mystery_data = [
  {
    // COLOR :  To change the color , go to the ex07.css and change the color there
    className: 'Mystery', // optional can be used for styling
    axes: [
      // value range [0,100], any values outside this range will change the values in the other axis
      {axis: "votes", value: 1}, 
      {axis: "rating", value: 1}, 
      {axis: "budget", value: 1},  
      {axis: "domesticprofit", value: 1},  
      {axis: "worldwideprofit", value: 1},
      {axis: "totalprofit", value: 1}
    ]
  }
];
var romance_data = [
  {
    // COLOR :  To change the color , go to the ex07.css and change the color there
    className: 'Romance', // optional can be used for styling
    axes: [
      // value range [0,100], any values outside this range will change the values in the other axis
      {axis: "votes", value: 1}, 
      {axis: "rating", value: 1}, 
      {axis: "budget", value: 1},  
      {axis: "domesticprofit", value: 1},  
      {axis: "worldwideprofit", value: 1},
      {axis: "totalprofit", value: 1}
    ]
  }
];
var scifi_data = [
  {
    // COLOR :  To change the color , go to the ex07.css and change the color there
    className: 'Sci-Fi', // optional can be used for styling
    axes: [
      // value range [0,100], any values outside this range will change the values in the other axis
      {axis: "votes", value: 1}, 
      {axis: "rating", value: 1}, 
      {axis: "budget", value: 1},  
      {axis: "domesticprofit", value: 1},  
      {axis: "worldwideprofit", value: 1},
      {axis: "totalprofit", value: 1}
    ]
  }
];
var thriller_data = [
  {
    // COLOR :  To change the color , go to the ex07.css and change the color there
    className: 'Thriller', // optional can be used for styling
    axes: [
      // value range [0,100], any values outside this range will change the values in the other axis
      {axis: "votes", value: 1}, 
      {axis: "rating", value: 1}, 
      {axis: "budget", value: 1},  
      {axis: "domesticprofit", value: 1},  
      {axis: "worldwideprofit", value: 1},
      {axis: "totalprofit", value: 1}
    ]
  }
];
var other_data = [
  {
    // COLOR :  To change the color , go to the ex07.css and change the color there
    className: 'Other', // optional can be used for styling
    axes: [
      // value range [0,100], any values outside this range will change the values in the other axis
      {axis: "votes", value: 1}, 
      {axis: "rating", value: 1}, 
      {axis: "budget", value: 1},  
      {axis: "domesticprofit", value: 1},  
      {axis: "worldwideprofit", value: 1},
      {axis: "totalprofit", value: 1}
    ]
  }
];
var no_data = [
  {
    // COLOR :  To change the color , go to the ex07.css and change the color there
    className: 'none', // optional can be used for styling
    title: 'No Selection',
    axes: [
      // value range [0,100], any values outside this range will change the values in the other axis
      {axis: "votes", value: 2}, 
      {axis: "rating", value: 2}, 
      {axis: "budget", value: 2},  
      {axis: "domesticprofit", value: 2},  
      {axis: "worldwideprofit", value: 2},
      {axis: "totalprofit", value: 2}
    ]
  }
];
