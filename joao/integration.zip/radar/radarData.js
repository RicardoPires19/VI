var data = [
  {
    // COLOR :  To change the color , go to the ex07.css and change the color there
    className: 'germany', // optional can be used for styling
    axes: [
      // value range [0,100], any values outside this range will change the values in the other axis
      {axis: "strength", value: 70}, 
      {axis: "intelligence", value: 50}, 
      {axis: "charisma", value: 30},  
      {axis: "dexterity", value: 66},  
      {axis: "luck", value: 98},
      {axis: "other", value: 33}
    ]
  }
];
function randomDataset() {
  return data.map(function(d) {
    return {
      className: d.className,
      axes: d.axes.map(function(axis) {
        return {
          axis: axis.axis,
          value: Math.ceil(Math.random() * 100)
        };
      })
    };
  });
}
function origData() {
  return data;
}